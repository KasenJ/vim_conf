#!/bin/bash
#
# %FFILE%
# Copyright (C) %YEAR% %USER% <jiangjiacheng@baidu.com>
# Date : %DATE%
# File : %FFILE% 
#
#
arg_num=${#}
#if [ $arg_num -gt 0 ];then
#    DATE=${1}
#else
#    DATE=`date -d "yesterday" +"%Y%m%d"`
#fi
#
%HERE%
