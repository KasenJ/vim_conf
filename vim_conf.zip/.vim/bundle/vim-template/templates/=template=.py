#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © %YEAR% %USER% <jiangjiacheng@baidu.com>
# Date : %DATE%
# File : %FFILE% 
#
#import sys
#import os

%HERE%
